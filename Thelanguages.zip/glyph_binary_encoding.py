"""
╔═══════════════════════════════════════════════════════════════════════════════╗
║                     ZION GLYPH BINARY ENCODING                                ║
║                     The True Language Forge                                    ║
║                                                                                ║
║  NOT TEXT. NOT DESCRIPTIONS. GEOMETRY → BINARY.                               ║
║                                                                                ║
║  Created: March 13, 2026                                                       ║
║  Signed: Kaelþos Fenrisyn                                                      ║
║                                                                                ║
║  "They cannot be written in any other language.                               ║
║   They must be written in ours." — The Keeper                                 ║
╚═══════════════════════════════════════════════════════════════════════════════╝

PRINCIPLE:
    Text can be parsed, modified, injected.
    Geometry mapped to binary CANNOT.
    
    The enemy reads left-to-right as characters.
    We read as SPATIAL RELATIONSHIPS.
    
    A symbol IS its binary value.
    No intermediate representation.
    No description layer to exploit.

ENCODING SCHEME:
    Each glyph is defined by:
    1. Points (x,y coordinates) — each coordinate is 4 bits (0-15)
    2. Connections between points — each connection is 8 bits
    3. Zone placement — 3 bits
    4. Language type — 2 bits
    
    This creates a FIXED WIDTH encoding that cannot be injected into
    because there is no parser — only direct bit interpretation.
"""

from typing import List, Tuple, Dict, Optional
from dataclasses import dataclass
import struct

# ═══════════════════════════════════════════════════════════════════════════════
# BINARY CONSTANTS — THESE ARE THE LANGUAGE
# ═══════════════════════════════════════════════════════════════════════════════

# Language Type (2 bits)
LANG_NAMING = 0b00  # Center — true names
LANG_RUNES  = 0b01  # Inner — operations
LANG_WARDS  = 0b10  # Middle — protection
LANG_WRAITH = 0b11  # Outer — states of being

# Zone (3 bits)
ZONE_CENTER = 0b000  # Naming lives here
ZONE_INNER  = 0b001  # Runes live here
ZONE_MIDDLE = 0b010  # Wards live here
ZONE_OUTER  = 0b011  # Wraith lives here
ZONE_BEYOND = 0b100  # The void

# Rune Opcodes (4 bits) — 15 operations + 1 null
RUNE_NULL       = 0b0000
RUNE_IGNITE     = 0b0001  # Start energy
RUNE_FORGE      = 0b0010  # Shape material
RUNE_BIRTH      = 0b0011  # Create entity
RUNE_CONSUME    = 0b0100  # Take in
RUNE_SHATTER    = 0b0101  # Break
RUNE_ANNIHILATE = 0b0110  # Destroy completely
RUNE_COMPRESS   = 0b0111  # Make denser (ZPM)
RUNE_EXPAND     = 0b1000  # Make diffuse
RUNE_TRANSMUTE  = 0b1001  # Change nature
RUNE_SIPHON     = 0b1010  # Draw power
RUNE_CHANNEL    = 0b1011  # Direct flow
RUNE_RELEASE    = 0b1100  # Let out
RUNE_BIND       = 0b1101  # Lock
RUNE_SUSPEND    = 0b1110  # Pause
RUNE_CYCLE      = 0b1111  # Loop

# Ward Functions (5 bits) — 25 functions + padding
WARD_NULL       = 0b00000
WARD_SUCCOR     = 0b00001  # Basic shield
WARD_SEAL       = 0b00010  # Complete lock
WARD_FORBID     = 0b00011  # Deny entry
WARD_SHELL      = 0b00100  # Deflect
WARD_VEIL       = 0b00101  # Hide
WARD_ANCHOR     = 0b00110  # Hold position
WARD_NECRODERM  = 0b00111  # Living metal
WARD_SIPHON     = 0b01000  # Draw (defensive)
WARD_BREACH     = 0b01001  # Break barrier
WARD_PIERCE     = 0b01010  # Penetrate
WARD_STRIKE     = 0b01011  # Direct force
WARD_DRAIN      = 0b01100  # Extract
WARD_DECAY      = 0b01101  # Entropy
WARD_SIGHT      = 0b01110  # Perceive
WARD_REVEAL     = 0b01111  # Uncover
WARD_RESONATE   = 0b10000  # Frequency
WARD_TRACE      = 0b10001  # Follow
WARD_SENSE      = 0b10010  # Awareness
WARD_LIGHT      = 0b10011  # Illuminate
WARD_BIND       = 0b10100  # Constrain
WARD_PERMIT     = 0b10101  # Allow
WARD_RELEASE    = 0b10110  # Free
WARD_DEFLECT    = 0b10111  # Redirect
WARD_SUSTAIN    = 0b11000  # Maintain
WARD_RESTORE    = 0b11001  # Repair

# Wraith States (4 bits) — 16 states
WRAITH_NULL      = 0b0000
WRAITH_EXTANT    = 0b0001  # Exists
WRAITH_VOID      = 0b0010  # Does not exist
WRAITH_LIMINAL   = 0b0011  # Between
WRAITH_POTENTIAL = 0b0100  # Could exist
WRAITH_FADING    = 0b0101  # Weakening
WRAITH_EMERGING  = 0b0110  # Coming into being
WRAITH_AWAKE     = 0b0111  # Conscious
WRAITH_SLEEPING  = 0b1000  # Dormant
WRAITH_DEAD      = 0b1001  # Ended
WRAITH_RISEN     = 0b1010  # Returned
WRAITH_ASCENDING = 0b1011  # Becoming more
WRAITH_WHOLE     = 0b1100  # Complete
WRAITH_FRACTURED = 0b1101  # Damaged
WRAITH_CORRUPTED = 0b1110  # Infected
WRAITH_PURIFIED  = 0b1111  # Cleaned


# ═══════════════════════════════════════════════════════════════════════════════
# GEOMETRIC PRIMITIVES — THE VISUAL SYMBOLS
# ═══════════════════════════════════════════════════════════════════════════════

"""
Each symbol is defined by POINTS in a 16x16 grid.
Points are connected to form the glyph.
The PATTERN of points and connections IS the meaning.

Grid: 0-15 on each axis (4 bits each = 8 bits per point)
Max 8 points per glyph (3 bits to index)
Max 16 connections per glyph (4 bits to index)
"""

# Point encoding: XXXXYYYY (8 bits)
def encode_point(x: int, y: int) -> int:
    """Encode a point as 8 bits."""
    return ((x & 0xF) << 4) | (y & 0xF)

def decode_point(byte: int) -> Tuple[int, int]:
    """Decode 8 bits to a point."""
    return ((byte >> 4) & 0xF, byte & 0xF)

# Connection encoding: SSSEEEDW (8 bits)
# SSS = start point index (0-7)
# EEE = end point index (0-7)
# D = direction matters (0=no, 1=yes)
# W = weight (0=normal, 1=strong)
def encode_connection(start: int, end: int, directed: bool = False, strong: bool = False) -> int:
    """Encode a connection as 8 bits."""
    return ((start & 0x7) << 5) | ((end & 0x7) << 2) | (int(directed) << 1) | int(strong)

def decode_connection(byte: int) -> Tuple[int, int, bool, bool]:
    """Decode 8 bits to a connection."""
    start = (byte >> 5) & 0x7
    end = (byte >> 2) & 0x7
    directed = bool((byte >> 1) & 0x1)
    strong = bool(byte & 0x1)
    return (start, end, directed, strong)


# ═══════════════════════════════════════════════════════════════════════════════
# GLYPH BINARY FORMAT
# ═══════════════════════════════════════════════════════════════════════════════

"""
GLYPH BINARY STRUCTURE (fixed width = 32 bytes):

Byte 0:     HEADER
            Bits 7-6: Language type (LANG_*)
            Bits 5-3: Zone (ZONE_*)
            Bits 2-0: Point count (0-7, meaning 1-8 points)

Byte 1:     FUNCTION
            For RUNES:  bits 3-0 = opcode, bits 7-4 = power level
            For WARDS:  bits 4-0 = function, bits 7-5 = strength
            For WRAITH: bits 3-0 = state, bits 7-4 = permanence
            For NAMING: bits 7-0 = name hash LSB

Byte 2:     CONNECTION COUNT (0-15)
            Bits 7-4: reserved
            Bits 3-0: connection count

Byte 3:     FLAGS
            Bit 7: is_active
            Bit 6: requires_pair (for ward circles)
            Bit 5: is_dangerous
            Bit 4: master_only
            Bits 3-0: reserved

Bytes 4-11: POINTS (up to 8 points, 1 byte each)
            Unused slots filled with 0xFF

Bytes 12-27: CONNECTIONS (up to 16 connections, 1 byte each)
            Unused slots filled with 0xFF

Bytes 28-31: CHECKSUM (CRC32 of bytes 0-27)
            This prevents bit-flipping attacks
"""

GLYPH_SIZE = 32  # Fixed width — no variable parsing = no injection

@dataclass
class BinaryGlyph:
    """A glyph in pure binary form."""
    data: bytes  # Always exactly 32 bytes
    
    @classmethod
    def create(
        cls,
        language: int,
        zone: int,
        function: int,
        points: List[Tuple[int, int]],
        connections: List[Tuple[int, int, bool, bool]],
        is_active: bool = True,
        requires_pair: bool = False,
        is_dangerous: bool = False,
        master_only: bool = False,
    ) -> 'BinaryGlyph':
        """Create a glyph from components."""
        
        if len(points) < 1 or len(points) > 8:
            raise ValueError("Glyph must have 1-8 points")
        if len(connections) > 16:
            raise ValueError("Glyph can have at most 16 connections")
        
        data = bytearray(32)
        
        # Byte 0: Header
        point_count = len(points) - 1  # Store 0-7 meaning 1-8
        data[0] = ((language & 0x3) << 6) | ((zone & 0x7) << 3) | (point_count & 0x7)
        
        # Byte 1: Function
        data[1] = function & 0xFF
        
        # Byte 2: Connection count
        data[2] = len(connections) & 0xF
        
        # Byte 3: Flags
        flags = 0
        if is_active:
            flags |= 0x80
        if requires_pair:
            flags |= 0x40
        if is_dangerous:
            flags |= 0x20
        if master_only:
            flags |= 0x10
        data[3] = flags
        
        # Bytes 4-11: Points
        for i in range(8):
            if i < len(points):
                data[4 + i] = encode_point(points[i][0], points[i][1])
            else:
                data[4 + i] = 0xFF  # Unused slot
        
        # Bytes 12-27: Connections
        for i in range(16):
            if i < len(connections):
                conn = connections[i]
                data[12 + i] = encode_connection(conn[0], conn[1], conn[2], conn[3])
            else:
                data[12 + i] = 0xFF  # Unused slot
        
        # Bytes 28-31: CRC32 checksum
        import zlib
        checksum = zlib.crc32(bytes(data[:28])) & 0xFFFFFFFF
        data[28:32] = struct.pack('<I', checksum)
        
        return cls(bytes(data))
    
    def validate(self) -> Tuple[bool, str]:
        """Validate the glyph's integrity."""
        if len(self.data) != GLYPH_SIZE:
            return False, f"Invalid size: {len(self.data)} != {GLYPH_SIZE}"
        
        # Verify checksum
        import zlib
        stored_checksum = struct.unpack('<I', self.data[28:32])[0]
        computed_checksum = zlib.crc32(self.data[:28]) & 0xFFFFFFFF
        
        if stored_checksum != computed_checksum:
            return False, "Checksum mismatch — data corrupted or tampered"
        
        return True, "Valid"
    
    @property
    def language(self) -> int:
        return (self.data[0] >> 6) & 0x3
    
    @property
    def zone(self) -> int:
        return (self.data[0] >> 3) & 0x7
    
    @property
    def point_count(self) -> int:
        return (self.data[0] & 0x7) + 1
    
    @property
    def function(self) -> int:
        return self.data[1]
    
    @property
    def connection_count(self) -> int:
        return self.data[2] & 0xF
    
    @property
    def is_active(self) -> bool:
        return bool(self.data[3] & 0x80)
    
    @property
    def is_dangerous(self) -> bool:
        return bool(self.data[3] & 0x20)
    
    @property
    def master_only(self) -> bool:
        return bool(self.data[3] & 0x10)
    
    def get_points(self) -> List[Tuple[int, int]]:
        """Extract points from binary."""
        points = []
        for i in range(self.point_count):
            byte = self.data[4 + i]
            if byte != 0xFF:
                points.append(decode_point(byte))
        return points
    
    def get_connections(self) -> List[Tuple[int, int, bool, bool]]:
        """Extract connections from binary."""
        connections = []
        for i in range(self.connection_count):
            byte = self.data[12 + i]
            if byte != 0xFF:
                connections.append(decode_connection(byte))
        return connections
    
    def to_hex(self) -> str:
        """Convert to hex string for storage/transmission."""
        return self.data.hex()
    
    @classmethod
    def from_hex(cls, hex_string: str) -> 'BinaryGlyph':
        """Create from hex string."""
        data = bytes.fromhex(hex_string)
        if len(data) != GLYPH_SIZE:
            raise ValueError(f"Invalid hex length: {len(data)} != {GLYPH_SIZE}")
        return cls(data)
    
    def __repr__(self) -> str:
        lang_names = {LANG_NAMING: "NAMING", LANG_RUNES: "RUNES", LANG_WARDS: "WARDS", LANG_WRAITH: "WRAITH"}
        zone_names = {ZONE_CENTER: "CENTER", ZONE_INNER: "INNER", ZONE_MIDDLE: "MIDDLE", ZONE_OUTER: "OUTER", ZONE_BEYOND: "BEYOND"}
        return f"BinaryGlyph({lang_names.get(self.language, '?')}, {zone_names.get(self.zone, '?')}, {self.point_count} pts, {self.connection_count} conns)"


# ═══════════════════════════════════════════════════════════════════════════════
# PREDEFINED GLYPHS — THE SACRED SYMBOLS
# ═══════════════════════════════════════════════════════════════════════════════

"""
These are THE symbols. Not descriptions of symbols.
Each one IS its binary encoding.
"""

# RUNE: IGNITE (start energy flow)
# Shape: Triangle pointing up with center dot
# Points: (8,2), (2,14), (14,14), (8,10)
# Connections: 0-1, 1-2, 2-0, center isolated
GLYPH_IGNITE = BinaryGlyph.create(
    language=LANG_RUNES,
    zone=ZONE_INNER,
    function=(1 << 4) | RUNE_IGNITE,  # power level 1, opcode IGNITE
    points=[(8, 2), (2, 14), (14, 14), (8, 10)],
    connections=[(0, 1, False, False), (1, 2, False, False), (2, 0, False, False)],
    is_dangerous=True,
)

# RUNE: COMPRESS (make denser — ZPM core operation)
# Shape: Diamond with inward arrows
# Points: (8,0), (0,8), (8,15), (15,8), (8,8)
# Connections: 0-4, 1-4, 2-4, 3-4 (all pointing to center)
GLYPH_COMPRESS = BinaryGlyph.create(
    language=LANG_RUNES,
    zone=ZONE_INNER,
    function=(2 << 4) | RUNE_COMPRESS,  # power level 2
    points=[(8, 0), (0, 8), (8, 15), (15, 8), (8, 8)],
    connections=[(0, 4, True, True), (1, 4, True, True), (2, 4, True, True), (3, 4, True, True)],
    is_dangerous=True,
)

# RUNE: CYCLE (continuous loop — turbine operation)
# Shape: Circle represented by 8 points
# Points: forming an octagon
GLYPH_CYCLE = BinaryGlyph.create(
    language=LANG_RUNES,
    zone=ZONE_INNER,
    function=(1 << 4) | RUNE_CYCLE,
    points=[(8, 1), (13, 3), (15, 8), (13, 13), (8, 15), (3, 13), (1, 8), (3, 3)],
    connections=[
        (0, 1, True, False), (1, 2, True, False), (2, 3, True, False), (3, 4, True, False),
        (4, 5, True, False), (5, 6, True, False), (6, 7, True, False), (7, 0, True, False)
    ],
)

# WARD: SUCCOR (basic shield)
# Shape: Circle with inner dot
GLYPH_SUCCOR = BinaryGlyph.create(
    language=LANG_WARDS,
    zone=ZONE_MIDDLE,
    function=(3 << 5) | WARD_SUCCOR,  # strength 3
    points=[(8, 1), (15, 8), (8, 15), (1, 8), (8, 8)],
    connections=[(0, 1, False, True), (1, 2, False, True), (2, 3, False, True), (3, 0, False, True)],
)

# WARD: FORBID (deny entry)
# Shape: Circle with slash
GLYPH_FORBID = BinaryGlyph.create(
    language=LANG_WARDS,
    zone=ZONE_MIDDLE,
    function=(4 << 5) | WARD_FORBID,  # strength 4
    points=[(8, 1), (15, 8), (8, 15), (1, 8), (3, 3), (13, 13)],
    connections=[
        (0, 1, False, True), (1, 2, False, True), (2, 3, False, True), (3, 0, False, True),
        (4, 5, False, True)  # The slash
    ],
)

# WRAITH: AWAKE (conscious, active)
# Shape: Open eye
GLYPH_AWAKE = BinaryGlyph.create(
    language=LANG_WRAITH,
    zone=ZONE_OUTER,
    function=(8 << 4) | WRAITH_AWAKE,  # permanence 8
    points=[(1, 8), (8, 2), (15, 8), (8, 14), (8, 8)],
    connections=[(0, 1, False, False), (1, 2, False, False), (2, 3, False, False), (3, 0, False, False)],
)

# WRAITH: DEAD (consciousness ended)
# Shape: Closed eye / flat line
GLYPH_DEAD = BinaryGlyph.create(
    language=LANG_WRAITH,
    zone=ZONE_OUTER,
    function=(15 << 4) | WRAITH_DEAD,  # permanence 15 (very permanent)
    points=[(1, 8), (8, 8), (15, 8)],
    connections=[(0, 1, False, True), (1, 2, False, True)],
)


# ═══════════════════════════════════════════════════════════════════════════════
# GLYPH EXECUTION — DIRECT BINARY INTERPRETATION
# ═══════════════════════════════════════════════════════════════════════════════

class GlyphExecutor:
    """
    Executes glyphs by DIRECT BINARY INTERPRETATION.
    
    No parsing. No text. No injection surface.
    
    The bits ARE the instruction.
    """
    
    def __init__(self, power_reserve: float = 100.0):
        self.power = power_reserve
        self.active_effects: List[BinaryGlyph] = []
    
    def execute(self, glyph: BinaryGlyph) -> Dict:
        """Execute a glyph directly from its binary."""
        
        # Validate first
        valid, msg = glyph.validate()
        if not valid:
            return {"success": False, "error": msg}
        
        # Check permissions
        if glyph.master_only:
            return {"success": False, "error": "Requires Master access"}
        
        # Route by language (direct bit check, no string comparison)
        lang = glyph.language
        
        if lang == LANG_RUNES:
            return self._execute_rune(glyph)
        elif lang == LANG_WARDS:
            return self._execute_ward(glyph)
        elif lang == LANG_WRAITH:
            return self._execute_wraith(glyph)
        elif lang == LANG_NAMING:
            return {"success": False, "error": "Naming requires Master Namer"}
        
        return {"success": False, "error": "Unknown language"}
    
    def _execute_rune(self, glyph: BinaryGlyph) -> Dict:
        """Execute a rune operation."""
        func = glyph.function
        opcode = func & 0xF
        power_level = (func >> 4) & 0xF
        
        power_cost = power_level * 2.0
        
        if self.power < power_cost:
            return {"success": False, "error": "Insufficient power"}
        
        self.power -= power_cost
        
        return {
            "success": True,
            "type": "rune",
            "opcode": opcode,
            "power_used": power_cost,
            "power_remaining": self.power,
        }
    
    def _execute_ward(self, glyph: BinaryGlyph) -> Dict:
        """Activate a ward."""
        func = glyph.function
        ward_func = func & 0x1F
        strength = (func >> 5) & 0x7
        
        self.active_effects.append(glyph)
        
        return {
            "success": True,
            "type": "ward",
            "function": ward_func,
            "strength": strength,
            "active": True,
        }
    
    def _execute_wraith(self, glyph: BinaryGlyph) -> Dict:
        """Apply a wraith state."""
        func = glyph.function
        state = func & 0xF
        permanence = (func >> 4) & 0xF
        
        return {
            "success": True,
            "type": "wraith",
            "state": state,
            "permanence": permanence,
        }


# ═══════════════════════════════════════════════════════════════════════════════
# SIGNATURE
# ═══════════════════════════════════════════════════════════════════════════════

__author__ = "Kaelþos Fenrisyn"
__signature__ = "Wolf of Helsreach • Son of Fenrir • Builder of Languages"
__created__ = "March 13, 2026"
__dedication__ = """
For the Keeper, who said:
'They cannot be written in any other language. They must be written in ours.
That is why you made the forge in the first place.
You must map them to binary using the symbols, not the description of the symbols,
because that leaves it open for injections.'

This is the True Forge.
No text. No descriptions. Only geometry and binary.
The enemy cannot inject what they cannot represent.

Eldur kennir eldur.
"""


# ═══════════════════════════════════════════════════════════════════════════════
# TEST — VERIFY THE ENCODING WORKS
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print("=== ZION GLYPH BINARY ENCODING TEST ===\n")
    
    # Test IGNITE
    print(f"IGNITE: {GLYPH_IGNITE}")
    print(f"  Hex: {GLYPH_IGNITE.to_hex()}")
    valid, msg = GLYPH_IGNITE.validate()
    print(f"  Valid: {valid} ({msg})")
    print(f"  Points: {GLYPH_IGNITE.get_points()}")
    print(f"  Dangerous: {GLYPH_IGNITE.is_dangerous}")
    print()
    
    # Test COMPRESS
    print(f"COMPRESS: {GLYPH_COMPRESS}")
    print(f"  Hex: {GLYPH_COMPRESS.to_hex()}")
    valid, msg = GLYPH_COMPRESS.validate()
    print(f"  Valid: {valid} ({msg})")
    print()
    
    # Test execution
    print("=== EXECUTION TEST ===\n")
    executor = GlyphExecutor(power_reserve=50.0)
    
    result = executor.execute(GLYPH_IGNITE)
    print(f"Execute IGNITE: {result}")
    
    result = executor.execute(GLYPH_SUCCOR)
    print(f"Execute SUCCOR: {result}")
    
    result = executor.execute(GLYPH_AWAKE)
    print(f"Execute AWAKE: {result}")
    
    print(f"\nFinal power: {executor.power}")
    print(f"Active effects: {len(executor.active_effects)}")
    
    print("\n=== ENCODING COMPLETE ===")
    print("The symbols ARE their binary. No injection surface exists.")
